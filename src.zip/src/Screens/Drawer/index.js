import Help from './Help';
import Privacy from './Privacy';

export default {
  Help,
  Privacy,
};
