import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const Help = () => {
  return (
    <View>
      <Text>Help</Text>
    </View>
  );
};

export default Help;

const styles = StyleSheet.create({});
