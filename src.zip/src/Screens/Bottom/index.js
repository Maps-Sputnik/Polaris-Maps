import Navigation from './Navigation';
import Messages from './Messages';
import Saved from './Saved';
import Profile from './Profile';

export default {
  Navigation,
  Messages,
  Saved,
  Profile,
};
