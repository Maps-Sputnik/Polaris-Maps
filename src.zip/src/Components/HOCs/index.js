import LoadingHoc from './LoadingHoc';

export default {
  LoadingHoc,
};
