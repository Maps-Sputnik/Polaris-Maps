import Container from './Atoms/Container';
import Opacity from './Atoms/TouchableOpacity';
import CustomIcon from './Atoms/CustomIcon';

export default {
  Container,
  Opacity,
  CustomIcon,
};
