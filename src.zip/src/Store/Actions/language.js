import { CHANGE_LANGUAGE } from './types';

export const changeLanguage = (payload) => ({
  type: CHANGE_LANGUAGE,
  payload,
});
