import requestFriend from './request';

export default {
  requestFriend,
};
