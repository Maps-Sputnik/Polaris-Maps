import getContacts from './GetContacts';

export default {
  getContacts,
};
