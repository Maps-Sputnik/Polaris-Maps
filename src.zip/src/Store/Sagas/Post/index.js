import fetch from './fetch';

export default {
  fetch,
};
