import getAccessToken from './getAccessToken';

export default {
  getAccessToken,
};
