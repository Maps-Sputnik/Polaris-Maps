export const staticUsers = [
  {
    id: 0,
    name: 'John Doe',
    avatar: require('@assets/Images/person.jpg'),
  },
  {
    id: 1,
    name: 'Jenice Doe',
    avatar: require('@assets/Images/person.jpg'),
  },
  {
    id: 2,
    name: 'John Doe',
    avatar: require('@assets/Images/person.jpg'),
  },
  {
    id: 3,
    name: 'Jenice Doe',
    avatar: require('@assets/Images/person.jpg'),
  },
];
